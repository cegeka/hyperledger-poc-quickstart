#!/bin/bash
source "$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"/_loader.sh
echo
echo NOTE: createComposerProfile is deprecated from v0.15.0  Please use createPeerAdminCard.sh 
